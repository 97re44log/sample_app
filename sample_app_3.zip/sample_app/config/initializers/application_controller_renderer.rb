# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'a016909cf5ec2bc732ea19a2ccb5e1b5476488bfe0875481a1b118211b950b8ddc87de5f0f40632ccf9323b5dbc30730b519ce85105bb030bd913deafdbc7125'